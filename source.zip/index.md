---
layout: default
title: BetaFest
---
<div class="container">
  <a href="#" class="card event-card">
    <img src="./assets/event/blocktober.png" alt="BetaFest: Blocktober" class="event-image">
  </a>
</div>